%Initialize constants for the simulation
clear
clc
close all

%%Define Constants
%%% ---- State Variables --------                                      %%
%%% x = [ vt    ( ft/sec )    - velocity                               %%  
%%%       alpha ( rad )       - angle of attack                        %%
%%%       beta  ( rad )       - sideslip angle                         %%
%%%       phi   ( rad )       - Euler angle                            %%
%%%       theta ( rad )       - Euler angle                            %%
%%%       psi   ( rad )       - Euler angle                            %%
%%%       P     ( rad/sec )   - roll rate                              %%
%%%       Q     ( rad/sec )   - pitch rate                             %%
%%%       R     ( rad/sec )   - yaw rate                               %%
%%%       integral of north speed    ( ft )  - north displacement      %%
%%%       integral of east speed     ( ft )  - east displacement       %%    
%%%       integral of vertical spped ( ft )  - altitude                %%
%%%       pow  ( percent, 0 <= pow <= 100 )   - power ];               %%
%%%                                                                    %%  

x0 = [500;   %ft/sec
    0.5;
   -0.2;
    -1;
    1;    
    -1;
    0.5;
    -0.6;
    0.7;
    1000;
    900;
    10000;
    90];

%%% ---- control Variables --------                                    %%   
%%% u = [ thtl ( 0 <= thtl <= 1.0 ) - throttle                         %%
%%%       el   ( deg )              - elevator                         %%
%%%       ail  ( deg )              - aileron                          %% 
%%%       rdr  ( deg )              - rudder ];                        %%

u = [0.8;
    0.1;    
    0.1;
    0.1];   

TF = 10;

% Saturation Constraints
u1min = 0;
u1max = 1;

u2min = -25*pi/180;
u2max = 25*pi/180;

u3min = -21.5*pi/180;
u3max = 21.5*pi/180;

u4min = -30*pi/180;
u4max = 30*pi/180;


%%Run the model
sim('F16_Sim.slx')
%sim('NL_F16_Controllers.slx')
%sim('L_F16_Controllers.slx')

% Plot the results
t = simX.Time;

u1 = simU.Data(:,1);
u2 = simU.Data(:,2);
u3 = simU.Data(:,3);
u4 = simU.Data(:,4);

x1 = simX.Data(:,1);
x2 = simX.Data(:,2);
x3 = simX.Data(:,3);
x4 = simX.Data(:,4);
x5 = simX.Data(:,5);
x6 = simX.Data(:,6);
x7 = simX.Data(:,7);
x8 = simX.Data(:,8);
x9 = simX.Data(:,9);
x10 = simX.Data(:,10);
x11 = simX.Data(:,11);
x12 = simX.Data(:,12);
x13 = simX.Data(:,13);

%plot Inputs
% u1,u2,u3,u4
figure
subplot(5,1,1)
plot(t,u3)
legend('u_3- Aileron')
grid on

subplot(5,1,2)
plot(t,u2)
legend('u_2- Elevator')
grid on

subplot(5,1,3)
plot(t,u4)
legend('u_4- Rudder')
grid on

subplot(5,1,4)
plot(t,u1)
legend('u_1- Engine Throttle ')
grid on

%plot the state
figure

%u,v,w
cbta = cos( x3 );
u = x1 .* cos( x2 ) .* cbta;
v = x1 .* sin( x3 );
w = x1 .* sin( x2 ) .* cbta;

subplot(3,3,1)
plot(t,u)
legend('x_1- u')
grid on

subplot(3,3,4)
plot(t,v)
legend('x_1- v')
grid on

subplot(3,3,7)
plot(t,w)
legend('x_1- w')
grid on

%p.q.r
subplot(3,3,2)
plot(t,x7)
legend('x_7- p')
grid on

subplot(3,3,5)
plot(t,x8)
legend('x_8- q')
grid on

subplot(3,3,8)
plot(t,x9)
legend('x_9- r')
grid on
