% Plot Root locus & Bode Plot of Linearized Longitudinal-Short Period & Phugoid(long period) Mode 
% & Lateral- Roll Mode, Spiral, DUtch Roll Dynamic Modes

clear;
clc;


% Longitudinal - short period & Phugoid
Alon = [0 0 0 1; -32.1 -0.013 -2.66 -1.18; 0 0 -0.67 0.93; 0 0 -0.57 -0.87];
Blon = [0; 0.0387; -0.0014; -0.1188];
Clon = [57.2958 0 0 0; 0 1 0 0; 0 0 57.2958 0; 0 0 0 57.2958];
Dlon = [0;0;0;0];

sslon = ss(Alon,Blon,Clon,Dlon);
tflon = tf(sslon);
tf2lon = tflon(2);
%pzmap(tf2lon);
%rlocus(tf2lon);
%bode(tf2lon);


%lateral  - Roll,Spiral, Dutch roll
Alan = [0 0 1 0.078; 0.064 -0.202 0.078 -0.99; 0 -22.92 -2.25 0.54; 0 6 -0.04 -0.31];
Blan = [0 0;0.0002 0.0005; -0.4623 0.0569; -0.0244 -0.0469];
Clan = [57.29 0 0 0; 0 57.29 0 0; 0 0 57.29 0; 0 0 0 57.29];
Dlan = [0 0;0 0;0 0;0 0];

sslat = ss(Alan,Blan,Clan,Dlan);
tflat = tf(sslat) ;
tf2lat = tflat(2,2);
%pzmap(tf2lat);
%rlocus(tf2lat);
bode(tf2lat);








